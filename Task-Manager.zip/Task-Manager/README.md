# Task-Manager
implemented a web-based task manager application where users can add, edit, and delete tasks. The app will allow users to organize their tasks, set due dates, mark tasks as completed, and categorize tasks.
